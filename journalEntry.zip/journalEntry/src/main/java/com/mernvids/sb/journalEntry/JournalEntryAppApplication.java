package com.mernvids.sb.journalEntry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JournalEntryAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(JournalEntryAppApplication.class, args);
	}

}
