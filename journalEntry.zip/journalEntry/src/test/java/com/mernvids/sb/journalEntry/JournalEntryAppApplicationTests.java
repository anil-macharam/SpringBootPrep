package com.mernvids.sb.journalEntry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JournalEntryAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
