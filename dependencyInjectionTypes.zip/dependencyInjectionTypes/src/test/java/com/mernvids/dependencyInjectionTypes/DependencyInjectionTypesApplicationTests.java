package com.mernvids.dependencyInjectionTypes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DependencyInjectionTypesApplicationTests {

	@Test
	void contextLoads() {
	}

}
