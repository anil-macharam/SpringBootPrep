package com.mernvids.sb.testLogic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestLogicApplicationTests {

	@Test
	void contextLoads() {
	}

}
