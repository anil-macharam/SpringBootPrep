package com.mernvids.sb.jdbcTemplateExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JdbcTemplateExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
