package com.mernvids.sb.requestParamPathVar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RequestParamPathVarApplicationTests {

	@Test
	void contextLoads() {
	}

}
