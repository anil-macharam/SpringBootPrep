package com.mernvids.sb.requestParamPathVar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RequestParamPathVarApplication {

	public static void main(String[] args) {
		SpringApplication.run(RequestParamPathVarApplication.class, args);
	}

}
