package com.mernvids.sb.beanScopeExamples;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeanScopeExamplesApplicationTests {

	@Test
	void contextLoads() {
	}

}
