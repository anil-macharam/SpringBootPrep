package com.mernvids.sb.beanScopeExamples;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeanScopeExamplesApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeanScopeExamplesApplication.class, args);
	}

}
